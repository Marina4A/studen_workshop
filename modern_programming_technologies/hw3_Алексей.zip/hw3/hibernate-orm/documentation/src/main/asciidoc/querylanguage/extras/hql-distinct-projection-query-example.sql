select distinct
    p.last_name
from
    person p
