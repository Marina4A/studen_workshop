CREATE TABLE Person (
    id BIGINT NOT NULL,
    phones VARCHAR(255) ARRAY,
    PRIMARY KEY ( id )
)