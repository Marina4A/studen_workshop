SELECT p1_0.id,
       p1_0."name"
FROM   Person p1_0
WHERE  p1_0.id = 1

SELECT id
FROM   Person
WHERE  id = 1
FOR    UPDATE