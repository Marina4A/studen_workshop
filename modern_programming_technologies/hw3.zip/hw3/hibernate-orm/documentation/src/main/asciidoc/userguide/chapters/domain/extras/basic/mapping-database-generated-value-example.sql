INSERT INTO Event ("timestamp", id)
VALUES (current_timestamp, 1)